try {
    (() => {
        var n = __$$hmAppManager$$__.currentApp;
        const g = n.current,
            {
                px: e
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(n, g)), n.app.__globals__),
            p = Logger.getLogger("watchface6");
        g.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: "4.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 0,
                    anim_path: "",
                    anim_prefix: "first_anim_jsoxz",
                    anim_ext: "png",
                    anim_fps: 15,
                    anim_size: 49,
                    display_on_restart: !1,
                    repeat_count: 0,
                    anim_status: hmUI.anim_status.START
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 219,
                    y: 241,
                    src: "5.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 17,
                    y: 16,
                    image_array: ["6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png"],
                    image_length: 10,
                    type: hmUI.data_type.BATTERY,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 168,
                    y: 8,
                    type: hmUI.data_type.BATTERY,
                    font_array: ["16.png", "17.png", "18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png", "25.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "26.png",
                    unit_tc: "26.png",
                    unit_en: "26.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 12,
                    y: 215,
                    src: "27.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 46,
                    hour_startY: 164,
                    hour_array: ["28.png", "29.png", "30.png", "31.png", "32.png", "33.png", "34.png", "35.png", "36.png", "37.png"],
                    hour_space: 0,
                    hour_unit_sc: "38.png",
                    hour_unit_tc: "38.png",
                    hour_unit_en: "38.png",
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 213,
                    minute_startY: 164,
                    minute_array: ["28.png", "29.png", "30.png", "31.png", "32.png", "33.png", "34.png", "35.png", "36.png", "37.png"],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 199,
                    am_y: 130,
                    am_sc_path: "39.png",
                    am_en_path: "40.png",
                    pm_x: 199,
                    pm_y: 130,
                    pm_sc_path: "41.png",
                    pm_en_path: "42.png",
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 260,
                    month_startY: 129,
                    month_sc_array: ["43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png"],
                    month_tc_array: ["43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png"],
                    month_en_array: ["43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png"],
                    month_unit_sc: "53.png",
                    month_unit_tc: "53.png",
                    month_unit_en: "53.png",
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: !1,
                    day_sc_array: ["43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png"],
                    day_tc_array: ["43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png"],
                    day_en_array: ["43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png"],
                    day_zero: 1,
                    day_follow: 1,
                    day_is_character: !1,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 219,
                    y: 241,
                    image_array: ["54.png", "55.png", "56.png", "57.png", "58.png", "59.png"],
                    image_length: 6,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 164,
                    y: 421,
                    type: hmUI.data_type.HEART,
                    font_array: ["43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png"],
                    align_h: hmUI.align.RIGHT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "60.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 357,
                    y: 214,
                    src: "61.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 161,
                    y: 418,
                    w: 54,
                    h: 28,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 252,
                    y: 257,
                    type: hmUI.data_type.STEP,
                    font_array: ["43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "62.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 212,
                    y: 256,
                    src: "63.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 210,
                    y: 252,
                    w: 130,
                    h: 30,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: "64.png",
                    show_level: hmUI.show_level.ONLY_AOD
                }),  hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 350,
                    y: 210,
                    w: 34,
                    h: 33,
                    type: hmUI.data_type.HEART,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 46,
                    hour_startY: 164,
                    hour_array: ["28.png", "29.png", "30.png", "31.png", "32.png", "33.png", "34.png", "35.png", "36.png", "37.png"],
                    hour_space: 0,
                    hour_unit_sc: "38.png",
                    hour_unit_tc: "38.png",
                    hour_unit_en: "38.png",
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 213,
                    minute_startY: 164,
                    minute_array: ["28.png", "29.png", "30.png", "31.png", "32.png", "33.png", "34.png", "35.png", "36.png", "37.png"],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                })
            },
            onInit() {
                p.log("index page.js on init invoke")
            },
            build() {
                this.init_view(), p.log("index page.js on ready invoke")
            },
            onDestory() {
                p.log("index page.js on destory invoke")
            }
        })
    })()
} catch (n) {
    console.log(n)
}
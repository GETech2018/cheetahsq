try {
    (() => {
        var n = __$$hmAppManager$$__.currentApp;
        const g = n.current,
            {
                px: p
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(n, g)), n.app.__globals__),
            e = Logger.getLogger("watchface6");
        g.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: "4.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                let anim = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 246,
                    anim_path: "",
                    anim_prefix: "first_anim_ripkg",
                    anim_ext: "png",
                    anim_fps: 15,
                    anim_size: 75,
                    repeat_count: 1,
                    anim_repeat: !1,
                    // display_on_restart: !0,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                let fail_anim = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 0,
                    y: 79,
                    anim_path: "",
                    anim_prefix: "second_anim_rllse",
                    anim_ext: "png",
                    anim_fps: 33,
                    anim_size: 120,
                    // display_on_restart: !1,
                    repeat_count: 0,
                    anim_repeat: true,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }); hmUI.createWidget(hmUI.widget.IMG_ANIM, {
                    x: 65,
                    y: 95,
                    anim_path: "",
                    anim_prefix: "third_anim_mdupj",
                    anim_ext: "png",
                    anim_fps: 33,
                    anim_size: 119,
                    // display_on_restart: !1,
                    repeat_count: 0,
                    anim_repeat: true,
                    anim_status: hmUI.anim_status.START,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 38,
                    hour_startY: 89,
                    hour_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    hour_space: 0,
                    hour_unit_sc: "15.png",
                    hour_unit_tc: "15.png",
                    hour_unit_en: "15.png",
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 207,
                    minute_startY: 89,
                    minute_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 172,
                    am_y: 186,
                    am_sc_path: "16.png",
                    am_en_path: "17.png",
                    pm_x: 172,
                    pm_y: 186,
                    pm_sc_path: "18.png",
                    pm_en_path: "19.png",
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 175,
                    y: 16,
                    type: hmUI.data_type.BATTERY,
                    font_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    align_h: hmUI.align.LEFT,
                    h_space: -1,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    unit_sc: "31.png",
                    unit_tc: "31.png",
                    unit_en: "31.png",
                    invalid_image: "30.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 43,
                    y: 186,
                    week_en: ["32.png", "33.png", "34.png", "35.png", "36.png", "37.png", "38.png"],
                    week_tc: ["39.png", "40.png", "41.png", "42.png", "43.png", "44.png", "45.png"],
                    week_sc: ["46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 258,
                    month_startY: 188,
                    month_sc_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    month_tc_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    month_en_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    month_unit_sc: "53.png",
                    month_unit_tc: "53.png",
                    month_unit_en: "53.png",
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: !1,
                    day_sc_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    day_tc_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    day_en_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    day_zero: 1,
                    day_follow: 1,
                    day_is_character: !1,
                    day_space: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 0,
                    y: 408,
                    w: 390,
                    h: 26,
                    icon: "54.png",
                    icon_space: 8,//icon到文字的间隔
                    type: hmUI.data_type.STEP,
                    font_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    align_h: hmUI.align.CENTER_H,
                    invalid_image: "20.png",
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: !1,
                    isCharacter: !1
                }),
                //  hmUI.createWidget(hmUI.widget.IMG, {
                //     x: 135,
                //     y: 408,
                //     src: "54.png",
                //     show_level: hmUI.show_level.ONLY_NORMAL
                // }),
                hmUI.createWidget(hmUI.widget.IMG_CLICK, {
                    x: 136,
                    y: 408,
                    w: 120,
                    h: 25,
                    type: hmUI.data_type.STEP,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 390,
                    h: 450,
                    src: "55.png",
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.IMG_TIME, {
                    hour_zero: 1,
                    hour_startX: 38,
                    hour_startY: 89,
                    hour_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    hour_space: 0,
                    hour_unit_sc: "15.png",
                    hour_unit_tc: "15.png",
                    hour_unit_en: "15.png",
                    hour_align: hmUI.align.LEFT,
                    minute_zero: 1,
                    minute_startX: 207,
                    minute_startY: 89,
                    minute_array: ["5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png"],
                    minute_space: 0,
                    minute_align: hmUI.align.LEFT,
                    minute_follow: 0,
                    am_x: 172,
                    am_y: 186,
                    am_sc_path: "16.png",
                    am_en_path: "17.png",
                    pm_x: 172,
                    pm_y: 186,
                    pm_sc_path: "18.png",
                    pm_en_path: "19.png",
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 43,
                    y: 186,
                    week_en: ["56.png", "57.png", "58.png", "59.png", "60.png", "61.png", "62.png"],
                    week_tc: ["39.png", "40.png", "41.png", "42.png", "43.png", "44.png", "45.png"],
                    week_sc: ["46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png"],
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    month_startX: 258,
                    month_startY: 188,
                    month_sc_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    month_tc_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    month_en_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    month_unit_sc: "53.png",
                    month_unit_tc: "53.png",
                    month_unit_en: "53.png",
                    month_align: hmUI.align.LEFT,
                    month_zero: 1,
                    month_follow: 0,
                    month_space: 0,
                    month_is_character: !1,
                    day_sc_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    day_tc_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    day_en_array: ["20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png"],
                    day_zero: 1,
                    day_follow: 1,
                    day_space: 0,
                    day_is_character: !1,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                })
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        console.log('ui resume');
                        // anim.setProperty(
                        //     hmUI.prop.ANIM_STATUS,
                        //     hmUI.anim_status.STOP
                        // );
                        anim.setProperty(
                            hmUI.prop.ANIM_STATUS,
                            hmUI.anim_status.START
                        );
                        fail_anim.setProperty(
                            hmUI.prop.ANIM_STATUS,
                            hmUI.anim_status.START
                        );
                    },
                    pause_call: function () {
                        console.log('ui pause');
                    },
                });
            },
            onInit() {
                e.log("index page.js on init invoke")
            },
            build() {
                this.init_view(), e.log("index page.js on ready invoke")
            },
            onDestory() {
                e.log("index page.js on destory invoke")
            }
        })
    })()
} catch (n) {
    console.log(n)
}